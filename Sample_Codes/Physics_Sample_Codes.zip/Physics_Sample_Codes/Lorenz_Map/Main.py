import numpy as np

def initialize(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, n, nout, m):
    print('Lorenz model: Euler (1) or Runge-Kutta [2nd ord] (2)?')
    m = int(input())
    print('parameters: sigma, r, b ?')
    sigma, r, b = map(float, input().split())
    print('initial x, y, z ?')
    x[0], y[0], z[0] = map(float, input().split())
    print('time step, how many steps ?')
    dt, n = map(float, input().split())
    n = int(n)
    t[0] = 0
    print('record output to a file [out.lorenz] ?')
    ans = input()
    if ans.lower() == 'y':
        nout = 1
    else:
        nout = 2
        print('plot [z vs t,z vs x](1) or [x , y vs t](2)?')
        k = int(input())
        if k not in [1, 2]:
            print('must select 1 or 2 ...')
            exit()
        print('set line, symbol?')
        ans = input()
        if ans.lower() == 'y':
            print('lsym, nsym ? -> ')
            lsym, nsym = map(float, input().split())
        else:
            lsym = 0
            nsym = 1
    return sigma, r, b, dt, lsym, nsym, k, n, nout, m

def calculate(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, nstep, m):
    nstep = min(nstep, 500000)
    if m == 2:
        for i in range(1, nstep):
            t[i] = t[i-1]+dt
            dx, dy, dz = dv(x[i-1], y[i-1], z[i-1], t[i-1], sigma, r, b)
            x1 = x[i-1]+0.5*dt*dx
            y1 = y[i-1]+0.5*dt*dy
            z1 = z[i-1]+0.5*dt*dz
            t1 = t[i-1]+0.5*dt
            dx, dy, dz = dv(x1, y1, z1, t1, sigma, r, b)
            x[i] = x[i-1]+dt*dx
            y[i] = y[i-1]+dt*dy
            z[i] = z[i-1]+dt*dz
    else:
        for i in range(1, nstep):
            t[i] = t[i-1]+dt
            dx, dy, dz = dv(x[i-1], y[i-1], z[i-1], t[i-1], sigma, r, b)
            x[i] = x[i-1]+dt*dx
            y[i] = y[i-1]+dt*dy
            z[i] = z[i-1]+dt*dz
    return

def dv(x0, y0, z0, t0, sigma, r, b):
    dx = sigma*(y0-x0)
    dy = -x0*z0+r*x0-y0
    dz = x0*y0-b*z0
    return dx, dy, dz

def display(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, n, m):
    with open('graph.out', 'w') as f:
        f.write('Time(s)             x             y             z\n')
        for i in range(n):
            f.write(f'{t[i]:12.5f} {x[i]:12.5f} {y[i]:12.5f} {z[i]:12.5f}\n')
    print('Data successfully written to graph.out for comparison.')
    return

def main():
    x = np.zeros(500003)
    y = np.zeros(500003)
    z = np.zeros(500003)
    t = np.zeros(500003)
    sigma, r, b = 0, 0, 0
    dt, lsym, nsym, k, n, nout, m = 0, 0, 0, 0, 0, 0, 0
    sigma, r, b, dt, lsym, nsym, k, n, nout, m = initialize(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, n, nout, m)
    calculate(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, n, m)
    if nout == 1:
        with open('out.lorenz', 'w') as f:
            for i in range(n):
                f.write(f'{t[i]:12.5e} {x[i]:12.5e} {y[i]:12.5e} {z[i]:12.5e}\n')
    else:
        display(x, y, z, t, sigma, r, b, dt, lsym, nsym, k, n, m)

if __name__ == "__main__":
    main()