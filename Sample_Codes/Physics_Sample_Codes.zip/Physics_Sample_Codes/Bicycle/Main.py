import numpy as np

def initialize(t, velocity, dt, power, mass, nmax, c, area, density, lsym, nsym, method):
    """
    Initialize variables
    """
    yes = 'y'
    print('Euler (1) or Runge-Kutta (2)? -> ')
    method = int(input())
    if method != 1 and method != 2:
        print('must select 1 or 2 ..')
        exit()
    print('initial velocity -> ')
    velocity[0] = float(input())
    t[0] = 0
    print('time step -> ')
    dt = float(input())
    print('max time -> ')
    tmax = float(input())
    nmax = min(int(tmax/dt), 5000)
    print('constant power -> ')
    power = float(input())
    mass = 70
    c = 0.5
    area = 0.33
    density = 1.29
    print('set line, symbol?')
    ans = input()
    if ans == yes:
        print('line and symbol numbers -> ')
        lsym = int(input())
        nsym = int(input())
    else:
        lsym = -1
        nsym = 1
    return dt, power, mass, nmax, c, area, density, lsym, nsym, method

def calculate(t, v, dt, power, mass, nmax, c, area, density, lsym, nsym, method):
    """
    Now use the Euler method or the Runge-Kutta (2nd order)
    """
    if method == 1:
        for i in range(nmax-1):
            v[i+1] = v[i] + dt * f(v[i], power, mass, c, density, area)
            t[i+1] = t[i] + dt
    else:
        for i in range(nmax-1):
            v1 = v[i] + 0.5 * dt * f(v[i], power, mass, c, density, area)
            v[i+1] = v[i] + dt * f(v1, power, mass, c, density, area)
            t[i+1] = t[i] + dt

def f(v, p, x, c, rho, a):
    if x == 0:
        return float('inf') if p > 0 else float('-inf')
    return (p/v - c*rho*a*v**2)/x

def display(t, velocity, dt, power, mass, nmax, c, area, density, lsym, nsym, method):
    """
    Modified to write simple text output to "graph.out" for comparison.
    """
    with open('graph.out', 'w') as f:
        f.write('Time(s)           Velocity(m/s)\n')
        for i in range(nmax):
            f.write(f'{t[i]} {velocity[i]}\n')
    print('Data successfully written to graph.out for comparison.')

def main():
    t = np.zeros(5003)
    velocity = np.zeros(5003)
    dt = 0
    power = 0
    mass = 0
    nmax = 0
    c = 0
    area = 0
    density = 0
    lsym = 0
    nsym = 0
    method = 0
    dt, power, mass, nmax, c, area, density, lsym, nsym, method = initialize(t, velocity, dt, power, mass, nmax, c, area, density, lsym, nsym, method)
    calculate(t, velocity, dt, power, mass, nmax, c, area, density, lsym, nsym, method)
    display(t, velocity, dt, power, mass, nmax, c, area, density, lsym, nsym, method)

if __name__ == '__main__':
    main()