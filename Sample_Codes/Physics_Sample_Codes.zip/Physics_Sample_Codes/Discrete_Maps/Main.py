import math

def f(x, b):
    """
    Logistic function f(x) = 4bx(1-x)
    """
    return 4.0 * b * x * (1.0 - x)

def g(x, a):
    """
    Cusp function g(x) = a(1-2|x-1/2|)
    """
    return a * (1.0 - 2.0 * abs(x - 0.5))

def h(x, c):
    """
    4th order function h(x) = c[1-(2x-1)^4]
    """
    return c * (1.0 - (2.0 * x - 1.0) ** 4)

def initialize():
    """
    Initialize parameters and file name
    """
    print("which map? logistic (1), cusp (2), 4th order (3)?")
    map = int(input())
    if map == 1:
        print("b in f(x)=4bx(1-x) ?")
        b = float(input())
        a = None
        c = None
    elif map == 2:
        print("a in g(x)=a(1-2|x-1/2|) ?")
        a = float(input())
        b = None
        c = None
    else:
        print("c in h(x)=c[1-(2x-1)**4] ?")
        c = float(input())
        a = None
        b = None

    print("initial x ?")
    x0 = float(input())
    print("how may iterations?")
    iter = int(input())
    print("output file?")
    of = input()

    return x0, map, a, b, c, iter, of

def main():
    yes = 'y'
    while True:
        x0, map, a, b, c, iter, of = initialize()
        with open(of, 'w') as output_file:
            x = x0
            iter1 = iter + 1
            if map == 1:
                for i in range(iter1):
                    print("{:.5e} {:.5e}".format(i-1, x), file=output_file)
                    x = f(x, b)
            elif map == 2:
                for i in range(iter1):
                    print("{:.5e} {:.5e}".format(i-1, x), file=output_file)
                    x = g(x, a)
            else:
                for i in range(iter1):
                    print("{:.5e} {:.5e}".format(i-1, x), file=output_file)
                    x = h(x, c)

        print("another try ?")
        ans = input()
        if ans != yes:
            break

if __name__ == "__main__":
    main()