#include <stdio.h>
#include <stdlib.h>
#include <math.h>

typedef struct {
    double uranium[2000];
    double lambda;
    double tau;
    double dt;
} decay_t;

void euler(decay_t* decay, int n) {
    decay->uranium[0] = 1000.0; // Initial condition
    for (int i = 1; i <= n; i++) {
        decay->uranium[i] = decay->uranium[i-1] - decay->uranium[i-1] / decay->tau * decay->dt;
    }
}

void runge_kutta_2nd_order(decay_t* decay, int n) {
    decay->uranium[0] = 1000.0; // Initial condition
    for (int i = 1; i <= n; i++) {
        double k1 = -decay->uranium[i-1] / decay->tau;
        double k2 = -(decay->uranium[i-1] + k1 * decay->dt / 2) / decay->tau;
        decay->uranium[i] = decay->uranium[i-1] + k2 * decay->dt;
    }
}

void runge_kutta_4th_order(decay_t* decay, int n) {
    decay->uranium[0] = 1000.0; // Initial condition
    for (int i = 1; i <= n; i++) {
        double k1 = -decay->uranium[i-1] / decay->tau;
        double k2 = -(decay->uranium[i-1] + k1 * decay->dt / 2) / decay->tau;
        double k3 = -(decay->uranium[i-1] + k2 * decay->dt / 2) / decay->tau;
        double k4 = -(decay->uranium[i-1] + k3 * decay->dt) / decay->tau;
        decay->uranium[i] = decay->uranium[i-1] + (k1 + 2 * k2 + 2 * k3 + k4) * decay->dt / 6;
    }
}

int main() {
    int method;
    double initial_nuclei;
    double tau;
    double dt;
    double total_time;
    char set_line_symbol;
    int line_number;
    int symbol_number;

    printf("Euler (1), Runge-Kutta 2nd order (2), 4th (3) ? -> ");
    scanf("%d", &method);
    printf("initial number of nuclei -> ");
    scanf("%lf", &initial_nuclei);
    printf("time constant -> ");
    scanf("%lf", &tau);
    printf("time step -> ");
    scanf("%lf", &dt);
    printf("total time -> ");
    scanf("%lf", &total_time);
    printf("set line, symbol? ");
    scanf(" %c", &set_line_symbol);
    if (set_line_symbol == 'y' || set_line_symbol == 'Y') {
        printf("line and symbol numbers -> ");
        scanf("%d %d", &line_number, &symbol_number);
    }

    decay_t decay;
    decay.lambda = log(2) / tau;
    decay.tau = tau;
    decay.dt = dt;

    int n = (int) (total_time / dt);

    switch (method) {
        case 1:
            euler(&decay, n);
            printf("Radioactive Decay: Euler               \n");
            break;
        case 2:
            runge_kutta_2nd_order(&decay, n);
            printf("Radioactive Decay: Runge-Kutta2        \n");
            break;
        case 3:
            runge_kutta_4th_order(&decay, n);
            printf("Radioactive Decay: Runge-Kutta4        \n");
            break;
        default:
            printf("Invalid method\n");
            return 1;
    }

    printf("tau = %10.8f    \n", tau);
    printf("dt = %10.8f    \n", dt);
    printf("=\n");
    printf("Time (s) | Number of Nuclei\n");
    printf("-\n");
    for (int i = 0; i <= n; i++) {
        printf("%10.4f | %14.2f\n", i * dt, decay.uranium[i]);
    }

    return 0;
}